#-*-coding:utf-8 -*-

import firebase_admin #서버 -> DB
from firebase_admin import credentials
from firebase_admin import firestore

a = input("DB에 보낼 값을 적어주세요. ")
cred = credentials.Certificate("ServiceAccountKey.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

doc_ref = db.collection(u'SPAM_Project').document(u'Raspberrypi')
doc_ref.set({
    u'Temp' : a
})
